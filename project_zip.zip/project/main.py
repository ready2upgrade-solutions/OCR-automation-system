from core.extractor import extract_document_text
import json

PDF_PATH = r"C:\Users\Meet patel\MEET\projects\ocr\testing_data\Rameshbhai_-_PAN_Card.pdf"

def main():
    pages = extract_document_text(PDF_PATH)

    output = {
        "total_pages": len(pages),
        "pages": pages
    }

    with open("output/result.json", "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print("✅ Text extraction completed (PDF + OCR fallback)")

if __name__ == "__main__":
    main()
